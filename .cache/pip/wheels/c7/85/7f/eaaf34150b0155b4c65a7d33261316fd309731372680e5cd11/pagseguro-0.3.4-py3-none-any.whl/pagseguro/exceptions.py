# coding: utf-8


class PagSeguroValidationError(Exception):
    pass
